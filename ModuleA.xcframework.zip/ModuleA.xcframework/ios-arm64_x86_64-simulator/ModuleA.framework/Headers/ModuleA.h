//
//  ModuleA.h
//  ModuleA
//
//  Created by Auzan Lazuardi on 29/02/24.
//

#import <Foundation/Foundation.h>

//! Project version number for ModuleA.
FOUNDATION_EXPORT double ModuleAVersionNumber;

//! Project version string for ModuleA.
FOUNDATION_EXPORT const unsigned char ModuleAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ModuleA/PublicHeader.h>


